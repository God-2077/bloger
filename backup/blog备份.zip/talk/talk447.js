
/*
* BotUI回复配置
*/
var botui = new BotUI("kelecnbot");
botui.message.bot({
   delay: 200,
   content: "Hi，大家好！👋👋👋"
}).then(function() {
   return botui.message.bot({
       delay: 1000,
       content: "我是space520，可以叫我space！"
   })
}).then(function() {
   return botui.message.bot({
       delay: 1000,
       content: "是一个爱在网上折腾的小傻...咳咳！"
   })
}).then(function(){
   // 限制递归的数量：
   return resCircle(5)
});
// .then(function() {
//     return botui.action.button({
//         delay: 1500,
//         action: [{
//             text: "牛逼呀！ 😃",
//             value: "and"
//         },
//         {
//             text: "少废话！ 🙄",
//             value: "gg"
//         }]
//     })
// }).then(function(res) {
//     // return resCircle(res)
//     if (res.value == "and") {
//         other()
//     }
//     if (res.value == "gg") {
//         return botui.message.bot({
//             delay: 1500,
//             content: "本来还想介绍小姐姐给你认识，溜了溜了... ![告辞](https://chevereto.hwb0307.com/images/2022/10/16/wallhaven-85x3v2.md.jpg)"
//         })
//     }
// });


// 异常对话相关的递归函数
// numCircle可以指定递归的最大次数。
var resCircle = function(numCircle) {

   // 一个关于消极态度的集合
   var negEva = ["有小姐姐吗？","我要看小姐姐。","小姐姐，在吗？"]; 
   var indexNegEva = Math.floor((Math.random()*negEva.length)); 
   var negText = negEva[indexNegEva];

   // 一个关于消极态度response的集合
   var negResponse = ["本想介绍小姐姐给你认识，溜了溜了", "不要小姐姐了吗？", "嘿嘿，小姐姐是我的了！", "88，小姐姐跟我睡觉了！"]; 
   var indexNegResponse = Math.floor((Math.random()*negResponse.length)); 
   var negResponseText = negResponse[indexNegResponse];

   // 随机图链接
   var randPic = [
        "https://s1.ax1x.com/2023/01/23/pSYGbZj.jpg",
        "https://s1.ax1x.com/2023/01/23/pSYG7LQ.jpg"
        //"https://s1.ax1x.com/2023/01/23/pSJqRln.jpg",
        //"https://s1.ax1x.com/2023/01/23/pSJqWyq.jpg"
   ]; 
   var indexrandPic = Math.floor((Math.random()*randPic.length)); 
   var targetURL= randPic[indexrandPic];

   botui.action.button({
       delay: 1500,
       action: [{
           text: "大神呀！ 😃",
           value: "and"
       },
       {
           text: negText,
           value: "gg"
       }]
   }).then(function(res){
       if (res.value == "and") {
           botui.message.bot({
               delay: 1500,
               content: "非常感谢你的夸奖！"
           }).then(function(){
               other()
           })
       } else if (numCircle === 0) {
           botui.message.bot({
               delay: 1500,
               content: "LSP！你竟然不想称赞我一下...哎！"
           }).then(function(){
               other()
           })  
       } else {
           botui.message.bot({
               // loading: true,
               delay: 1500,
               // https://chevereto.hwb0307.com/images/2022/10/16/wallhaven-85x3v2.md.jpg
               // content: negResponseText + " ![告辞](https://blognas.hwb0307.com/checkbot/index.php)"
               content: negResponseText + '<br /><img src="' + targetURL + '">'
           }).then(function() {
               //content: negResponseText + '<br /><img src="' + targetURL + '" width="500">'
           //}).then(function() {
               var numCircle2 = numCircle - 1
               // console.log(numCircle)
               return resCircle(numCircle2)
           }) 
       }
   })
}

// 正常对话信息
var other = function() {
   // botui.message.bot({
   //     delay: 1500,
   //     content: "😘😘😘"
   // }).then(function() {
   //     return 
   botui.message.bot({
           delay: 1500,
           content: "我喜欢折腾有趣的事情ㄟ(▔,▔)ㄏ "
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "略懂HTML，目前正在学海中苦战。"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "你是不是说漏了什么呢？ 🤔",
               value: "next"
           }]
       })
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "咳咳，你没听错。"
       })
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "我目前是个学生。"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "哇，牛逼！ 👍👍👍",
               value: "next"
           }]
       })
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "不要这么说吧，我会飘的。☺😊😚"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "为什么叫 Space520 呢？ 🤔",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "很久以前(我初三暑假)"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "在域名注册时，好的域名都被人抢了"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "后来我脑子一灵"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "想到了这个  space520.42web.io"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "博主名就随随便便就选了Space520"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "然后就用习惯了 😄"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "您未来有什么计划吗？",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "好好学习，天天向上"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "早日减父母的负担"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "然后做自己喜欢的事"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "最后为中华民族的奋兴而奋斗"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "你好有志向呀",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "嗯..."
       })
    }).then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "您是不是漏了什么没说呀？（暗示）",
            value: "next"
            }]
        })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "对对，光顾着说自己了 (～￣▽￣)～ "
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "祝您身体健康、心想事成、前程似锦喽！"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "谢谢哈！那么如何支持您的工作呢？妈妈教育我不能白嫖...",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "常来看看就是我最大的荣幸！"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: '最后再次感谢！<img src="http://space520.42web.io/wp-content/uploads/2023/01/img_611_900x897_350_null_normal-1.jpg" alt="space520">'
       })
   });
}
