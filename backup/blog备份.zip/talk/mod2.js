/*
 * botui 0.3.4
 * A JS library to build the UI for your bot
 * https://botui.org
 *
 * Copyright 2017, Moin Uddin
 * Released under the MIT license.
 */
var botui = new BotUI("kelecnbot");
botui.message.bot({
    delay: 200,
    content: "Hi, 陌生人"
})
    .then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "欢迎你来到这里"
    })
})
    .then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "我是 space520 "
    })
})
    .then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "是一个爱在网上折腾的小傻...咳咳！"
    })
})
    .then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "嗯...^_^",
            value: "aaa"
        }, {
            text: "你真够废话！",
            value: "aab"
        }]
    })
})
    .then(function(res) {
    if (res.value == "aaa") {
        baa()
    }
    if (res.value == "aab") {
        bab()
    }
});
var bab = function() {
    botui.message.bot({
        delay: 1500,
        content: "似乎我们之间没有相同的话题？"
    })
        .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "但我还是很高兴你来到这里"
        })
    })
        .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: " (￣_,￣ ) "
        })
    });
}
var baa = function() {
    botui.message.bot({
        delay: 1500,
        content: "我喜欢折腾新事物和思考人生 ㄟ(▔,▔)ㄏ "
    });
}
