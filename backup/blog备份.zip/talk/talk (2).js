
/*
* BotUI回复配置
*/
var botui = new BotUI("kelecnbot");
botui.message.bot({
   delay: 200,
   content: "Hi，here"
}).then(function() {
   return botui.message.bot({
       delay: 1000,
       content: "这里是小曹"
   })
}).then(function() {
   return botui.message.bot({
       delay: 1000,
       content: "一个阳光的蓝孩子~"
   })
}).then(function(){
   // 限制递归的数量：
   return resCircle(8)
});


// 异常对话相关的递归函数
// numCircle可以指定递归的最大次数。
var resCircle = function(numCircle) {

   // 一个关于消极态度的集合
   var negEva = ["你小子少废话 🙄"]; 
   var indexNegEva = Math.floor((Math.random()*negEva.length)); 
   var negText = negEva[indexNegEva];

   // 一个关于消极态度response的集合
   var negResponse = ["本想介绍小姐姐给你认识，溜了溜了", "不要小姐姐了吗？", "不好意思，小姐姐归我了！", "哎，小姐姐只能独自伤心了。"]; 
   var indexNegResponse = Math.floor((Math.random()*negResponse.length)); 
   var negResponseText = negResponse[indexNegResponse];

   // 随机图链接
   var randPic = [
       "https://chevereto.hwb0307.com/images/2022/10/16/wallhaven-85x3v2.md.jpg",
	   "https://chevereto.hwb0307.com/images/2022/10/16/wallhaven-85x3v2.md.jpg"
   ]; 
   var indexrandPic = Math.floor((Math.random()*randPic.length)); 
   var targetURL= randPic[indexrandPic];

   botui.action.button({
       delay: 1500,
       action: [{
           text: "然后呢 😃",
           value: "and"
       },
       {
           text: negText,
           value: "gg"
       }]
   }).then(function(res){
       if (res.value == "and") {
           botui.message.bot({
               delay: 1500,
               content: "😘😘😘"
           }).then(function(){
               other()
           })
       } else if (numCircle === 0) {
           botui.message.bot({
               delay: 1500,
               content: "好了，不玩啦！你甚至不想称赞我哪怕一下...哎！"
           }).then(function(){
               other()
           })  
       } else {
           botui.message.bot({
               // loading: true,
               type: 'html',
               delay: 1500,
               content: negResponseText + '<br /><img src="' + targetURL + '" width="500">'
           }).then(function() {
               var numCircle2 = numCircle - 1
               // console.log(numCircle)
               return resCircle(numCircle2)
           }) 
       }
   })
}

// 正常对话信息
var other = function() {
   // }).then(function() {
   //     return 
   botui.message.bot({
           delay: 1500,
           content: "我喜欢折腾新事物和思考人生 ㄟ(▔,▔)ㄏ "
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "略懂HTML/Python，同时也是一名DJI飞手，图虫签约摄影师"
       })
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "XMU在读医学牲，目前正在中医学的道路上艰难求索..."
       })
   }).then(function() {
       return botui.message.bot({
           delay: 1500,
           content: "专业课之余还在学习js,css3,html5等语言ing"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "那你有什么爱好呢?",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "有好多，比如滑板、摄影、书法篆刻啊之类的"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "当然了，还有我心心念念的blog (～￣▽￣)～ "
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "这个网站是这么搭建的呢？",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "是基于wordpress进行自定义搭建的"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "今年有什么计划吗？",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "有啊，和朋友兄弟一起去西藏，感受拉萨朝圣气息，看南迦巴瓦的日照金山"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "去看一场许巍或者周杰伦的演唱会 (～￣▽￣)～"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "也要更多地关注时事、前沿和技术，潜心学习"
       })
   }).then(function() {
       return botui.action.button({
           delay: 1500,
           action: [{
               text: "那你为什么要搭建这个网站呢？",
               value: "next"
           }]
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "因为对blog有种执念 "
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "顺便也想记录一下自己的怪想法与摄影成果"
       })
   }).then(function(res) {
       return botui.message.bot({
           delay: 1500,
           content: "那么，仔细看看我的博客吧？ ^_^"
       })
   });
}
