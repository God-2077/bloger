//略部分配置代码
/*
 * botui 0.3.4
 * A JS library to build the UI for your bot
 * https://botui.org
 *
 * Copyright 2017, Moin Uddin
 * Released under the MIT license.
*/
//略部分配置代码
/*
 * BotUI回复配置，这个一看就懂，我就不详细解释了，要注意一下中文支持需要使用UTF-8编码格式，否则可能会乱码。
 */
var botui = new BotUI("kelecnbot");
botui.message.bot({
    delay: 200,
    content: "Hi, 陌生人"
}).then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "我是 space520 "
    })
}).then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "一个热爱技术的蓝孩子~😉😉😉"
    })
}).then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "然后呢？ 😃😃😃",
            value: "and"
        },
        {
            text: "少废话！ 🙄🙄🙄",
            value: "gg"
        }]
    })
}).then(function(res) {
    if (res.value == "and") {
        other()
    }
    if (res.value == "gg") {
        return botui.message.bot({
            delay: 1500,
            content: " ![告辞](https://cdn.jsdelivr.net/gh/kelecn/images@master/gaoci%20.jpg) "
        })
    }
});
 
var other = function() {
    botui.message.bot({
        delay: 1500,
        content: "😘😘😘"
    }).then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "目前在从事嵌入式、物联网、硬件方面的工作🐧🐧🐧"
        })
    }).then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "略懂HTML/CSS/JavaScript/Java，专攻C/C++/Python"
        })
    }).then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "日常兴趣：旅行、爬山、美食"
        })
    }).then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "喜欢动手，热爱学习新知识，热爱开源文化，目前正在嵌入式的道路上探索中💪💪💪"
        })
    }).then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "为什么叫 kelecn 呢？🤔🤔🤔",
                value: "next"
            }]
        })
    }).then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "因为很喜欢《刺客伍六七》里可乐这个角色，于是我就沿用了kele下来，嗯！"
        })
    }).then(function (res) {
    return botui.message.add({
      delay: 1500,
      type: 'embed',
      content: 'https://cdn.jsdelivr.net/gh/kelecn/images@master/kele.gif'
    });
  }).then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "emmmmm，至于cn嘛，中国国家顶级域名2333"
        })
    }).then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "怎样可以联系你呢？(ง •_•)ง",
                value: "next"
            }]
        })
    }).then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "博客评论区留言或者是左下角的对话窗口留言都可以联系我哦~"
        })
    }).then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "欢迎联系我交流哦~🤗🤗🤗"
        })
    }).then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "有需要交换友链的朋友，欢迎点击友链页提交哦~😋😋😋"
        })
    }).then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "那么，仔细看看我的博客吧？ ^_^"
        })
    }).then(function() {
        return botui.message.bot({
            delay: 3000,
            content: "还有，欢迎关注我的 [GitHub](https://github.com/kelecn)哦 ！🤗🤗🤗"
        })
    }).then(function() {
        return botui.message.bot({
            delay: 1500,
            content: " [![GitHub](https://cdn.jsdelivr.net/gh/kelecn/images@master/%E6%82%9F%E7%A9%BA.jpg)](https://github.com/kelecn) "
        })
    });
}