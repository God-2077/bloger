/*
 * botui 0.3.4
 * A JS library to build the UI for your bot
 * https://botui.org
 *
 * Copyright 2017, Moin Uddin
 * Released under the MIT license.
 */
var botui = new BotUI("kelecnbot");
botui.message.bot({
    delay: 200,
    content: "Hi, 陌生人"
})
    .then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "欢迎你来到这里"
    })
})
    .then(function() {
    return botui.message.bot({
        delay: 1000,
        content: "我是space520，可以叫我space！"
    })
})
    .then(function() {
    return botui.message.bot({
        delay: 1500,
        content: "我是一个阳光的小男孩。"
    })
})
    .then(function() {
    return botui.message.bot({
        delay: 1500,
        content: "也是一个爱在网上折腾的小傻...咳咳！"
    })
})
    .then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "嗯...^_^",
            value: "aaa"
        }, {
            text: "你真够废话！",
            value: "aab"
        }]
    })
})
    .then(function(res) {
    if (res.value == "aaa") {
        baa()
    }
    if (res.value == "aab") {
        bab()
    }
});


var bab = function() {
    botui.message.bot({
        delay: 1500,
        content: "似乎我们之间没有相同的话题？"
    })
        .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "但我还是很高兴你来到这里"
        })
    })
        .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: " (￣_,￣ ) "
        })
    })
    .then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "对不起,我一时冲动╮(╯▽╰)╭,",
            value: "aac"
        }, {
            text: "byebye",
            value: "aad"
        }]
    })
})
    .then(function(res) {
    if (res.value == "aac") {
        bac()
    }
    if (res.value == "aad") {
        bad()
    }
});
}
var bac = function() {
    botui.message.bot({
        delay: 1500,
        content: "没关系，能理解。"
    })
         .then(function() {
            baa()
            });
}
var bad = function() {
    botui.message.bot({
        delay: 1500,
        content: "告辞"
    });
}
var baa = function() {
    botui.message.bot({
        delay: 1500,
        content: "我喜欢折腾新事物和思考人生 ㄟ(▔,▔)ㄏ "
    })
            .then(function(res) {
        return botui.message.bot({
            delay: 1500,
            content: "略懂HTML，目前正在学海中苦战。"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "你是不是说漏了什么呢？",
                value: "next"
            }]
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "咳咳，你没听错。"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "我目前是个中学生。"
        })
    })
               .then(function() {
          return botui.action.button({
          delay: 1500,
          action: [{
            text: "哇，牛逼！",
            value: "aa"
        }, {
            text: "你不会骗我的吧？",
            value: "ab"
        }]
       })
    })
        .then(function(res) {
    if (res.value == "aa") {
        aa()
    }
    if (res.value == "ab") {
        ab()
    }
});
}
var ab = function() {
    botui.message.bot({
        delay: 1000,
        content: "我没骗你。"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1000,
            content: "当我还是个中学生的时候"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "我就一手搭建了这个网站"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "怎么样，哥牛逼不？"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 800,
            content: "ヾ(≧∇≦*)ゝ"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "牛逼哥 ㄟ(≧◇≦)ㄏ",
                value: "next"
            }]
        })
    })
                .then(function() {
            aa()
        });
}
var aa = function() {
    botui.message.bot({
        delay: 1500,
        content: "不要这么说吧，我会飘的。"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "<(￣︶￣)>"
        })
    })
        .then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "你不介绍一下你的网站？",
            value: "ad"
        }, {
            text: "你有什么爱好呢?",
            value: "ae"
        },{
            text: "你为什么叫 Space520 呢？",
            value: "ag"
        }]
        })
    })
        .then(function(res) {
    if (res.value == "ad") {
        ad()
    }
    if (res.value == "ae") {
        ae()
    }
    if (res.value == "ag") {
        ag()
    }
    });
}
var ad = function() {
    botui.message.bot({
        delay: 1500,
        content: "在这里，你可以看到我的生活中有趣的事情"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "以及我写的或者转载的一些有趣有用的文章"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "太棒了！我一定要看看！",
                value: "next"
            }]
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "当然！"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 800,
            content: "你还可以在这里发表你的评论"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "分享你的经验，和其他人一起交流"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "你也可以转载你在这里看到的有趣的文章，让更多的人可以看到"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "好的",
                value: "next"
            }]
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "感谢你"
        })
    })
            .then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "您这个网站是怎样搭建的呢？",
            value: "af"
        }, {
            text: "你有什么爱好呢?",
            value: "ae"
        },{
            text: "你为什么叫 Space520 呢？",
            value: "ag"
        }]
        })
    })
            .then(function(res) {
        if (res.value == "af") {
            af()
        }
        if (res.value == "ae") {
            ae()
        }
        if (res.value == "ag") {
            ag()
        }
    });
}
var ae = function() {
    botui.message.bot({
        delay: 1500,
        content: "有很多"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1000,
            content: "玩电脑游戏《坎巴拉太空计划》《GTA5》《大表哥2》"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "研究一下电脑病毒(因为这个我电脑重装了几次机)  ╮（╯＿╰）╭"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "学习 html html5 JavaScript Python"
        })
    })
        .then(function() {
    return botui.action.button({
        delay: 1500,
        action: [{
            text: "您这个网站是怎样搭建的呢？",
            value: "af"
        }, {
            text: "你不介绍一下你的网站？",
            value: "ad"
        },{
            text: "你为什么叫 Space520 呢？",
            value: "ag"
        }]
    })
    })
        .then(function(res) {
    if (res.value == "aaf") {
        af()
    }
    if (res.value == "ad") {
        ad()
    }
    if (res.value == "ag") {
        ag()
    }
});
}
var ag = function() {
    botui.message.bot({
        delay: 1500,
        content: "很久以前(我初三暑假)"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "在域名注册时，好的域名都被人抢了"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "后来我脑子一灵"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "想到了这个 space520.42web.io"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 800,
            content: "(￣▽￣)"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "博主名就随随便便就选了Space520"
        })
    })
                 .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "其实我的网名还有 迷雾老兵 god2077 水滴 等"
        })
    })
        .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "您这个网站是怎样搭建的呢？",
                value: "af"
            }, {
                text: "你不介绍一下你的网站？",
                value: "ad"
            },{
                text: "那你有什么爱好呢?",
                value: "ae"
            }]
        })
    })
                .then(function(res) {
        if (res.value == "aaf") {
            af()
        }
        if (res.value == "ad") {
            ad()
        }
        if (res.value == "ae") {
            ae()
        }
    });
}
var af = function() {
    botui.message.bot({
        delay: 1500,
        content: "我的网站是基于wordpress进行自定义搭建的"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "使用了agron主题，还看了许多的教程。"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "还有  Bensz - 苯苯 的帮助与支持"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "这是 Bensz - 苯苯 的网站"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "blognas.hwb0307.com"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "您未来有什么计划吗？",
                value: "next"
            }]
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "好好学习，天天向上"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "争取早日减父母的负担"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "然后做自己喜欢的事情"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "最后为中华民族的伟大奋兴而奋斗"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "您是不是漏了什么没说呀？（暗示）",
                value: "ah"
            }, {
                text: "你把民族放在最后一位，是不是说明你在某种程度上...",
                value: "ai"
            }]
        })
    })
            .then(function(res) {
        if (res.value == "ah") {
            ah()
        }
        if (res.value == "ai") {
            ai()
        }
    });
}
var ai = function() {
    botui.message.bot({
        delay: 1500,
        content: "东西可以乱吃，话可不能乱说呀！"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "我哪有别的想法?"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "主要是这行字太长了，放在后面不是比较美观。"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "您是不是漏了什么没说呀？（暗示）",
                value: "next"
            }]
        })
    })
                .then(function() {
            ah()
        });
}
var ah = function() {
    botui.message.bot({
        delay: 1500,
        content: "对对，光顾着说自己了 (～￣▽￣)～"
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "祝您身体健康、心想事成、前程似锦喽！"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "怎样可以联系你呢？(ง •_•)ง",
                value: "next"
            }]
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "博客评论区留言或者是发邮件给god_2077@outlook.com都可以联系我哦~"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "欢迎联系我交流哦~"
        })
    })
            .then(function() {
        return botui.action.button({
            delay: 1500,
            action: [{
                text: "我该如何支持你呢？",
                value: "next"
            }]
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "常来看看就是我最大的荣幸！"
        })
    })
                .then(function() {
        return botui.message.bot({
            delay: 1500,
            content: "那么，仔细看看我的博客吧？ ^_^"
        })
    })
}